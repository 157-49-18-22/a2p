$(document).ready(function() {
    $('.js-example-basic-single').select2({
        width: 'element',
    });
});
