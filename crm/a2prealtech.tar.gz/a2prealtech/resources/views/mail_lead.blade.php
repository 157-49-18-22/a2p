<html>
<head><title>A2P Realtech Pvt.Ltd. 2 Factor Authentication for Exporting Leads</title></head>
<body>
<p>Dear {{$name}}</p>

<p>Please find the 2 factor authentication code for Exporting Leads</p>
<h2>{{$code}}</h2>

<p>Regards<br/>A2P Realtech</p>

</body>
</html>