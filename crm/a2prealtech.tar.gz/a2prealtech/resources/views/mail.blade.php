<html>
<head><title>A2P Realtech Pvt.Ltd. 2 Factor Authentication</title></head>
<body>
<p>Dear {{$name}}</p>

<p>Please find the 2 factor authentication code for login to your dashboard</p>
<h2>{{$code}}</h2>

<p>Regards<br/>A2P Realtech</p>

</body>
</html>