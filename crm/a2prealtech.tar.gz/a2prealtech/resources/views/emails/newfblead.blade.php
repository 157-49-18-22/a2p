<p>Hi,</p>
<p>
    A new lead has been generated from our facebook ad cmapaign. The details of the lead is listed below
</p>
<ul>
    <li>Name: {{ $enquiry->name }}</li>
    <li>Contact number: <a href="tel:{{ $enquiry->contact_no }}">{{ $enquiry->contact_no }}</a></li>
</ul>
<br>
<p>Thank you.</p>
