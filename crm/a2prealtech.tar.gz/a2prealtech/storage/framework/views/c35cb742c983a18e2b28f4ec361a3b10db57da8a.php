<?php $__env->startSection('title', 'All Invoices'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>All Invoices</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('invoices.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add New Invoice</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Bill No</th>
                        <th class="text-uppercase" scope="col">Bill Date</th>
                        <th class="text-uppercase" scope="col">Company/Developer</th>
                        <th class="text-uppercase" scope="col">Property Amount</th>
                        <th class="text-uppercase" scope="col">Bill Status</th>
                        <th class="text-uppercase" scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($client->id); ?></td>
                        <td><?php echo e($client->bill_no); ?></td>
                        <td><?php echo e($client->bill_date); ?></td>
                        <td><?php echo e($client->company_developer); ?></td>
                        <td><?php echo e($client->property_amount); ?></td>
                        <td><?php echo e($client->bill_status); ?></td>
                       
                        <td>
                            <div class="dropdown">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-boundary="viewport">
                                    ACTIONS
                                </a>
                                <div id="<?php echo e($client->id); ?>" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_show')): ?>
                                    <a class="dropdown-item text-primary"
                                        href="<?php echo e(route('invoices.download', ['id' => $client->id])); ?>">Download</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_edit')): ?>
                                    <a class="dropdown-item text-primary"
                                        href="<?php echo e(route('invoices.edit', ['id' => $client->id])); ?>">Edit</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_delete')): ?>
                                    <?php if(!$client->is_active): ?>
                                     <!--    <div class="dropdown-divider"></div>
                                        <a role="button" class="entry-delete-btn dropdown-item text-danger" style="">
                                            Delete This Client
                                        </a> -->
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <input type="hidden" id="deleteUrl<?php echo e($client->id); ?>" value="<?php echo e(route('clients.destroy', ['id' => $client->id])); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
                    <input type="hidden" id="deletedTitle" value="Deleted!">
                    <input type="hidden" id="deletedMsg" value="Your request has been successfully completed.">

                </tbody>
            </table>
            <?php if(count($clients) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">
            <?php echo e($clients->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/invoices/index.blade.php ENDPATH**/ ?>