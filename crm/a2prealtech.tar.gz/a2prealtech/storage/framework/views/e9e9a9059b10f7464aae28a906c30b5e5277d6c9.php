<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Date</label>
        <input type="text" class="form-control text-capitalize" id="name" name="date" placeholder="Full Name"
        value="<?php if(isset($project)){$originalDate = $project->created_at;
			echo $newDate = date("d-M-Y", strtotime($originalDate));} else{echo Date('d-M-Y');}?>">
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Name</label>
        <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Project name"
        value="<?php if(isset($project)): ?><?php echo e($project->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" required>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Location</label>
        <input type="text" class="form-control text-capitalize" id="name" name="location" placeholder="Enter Location"
        value="<?php if(isset($project)): ?><?php echo e($project->location); ?><?php else: ?><?php echo e(old('location')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="details">Project Brochure</label>
        <input type="file" class="form-control" id="brochure" name="brochure" >
    </div>
</div>
<div class="row">
   
    <div class="form-group col-sm-8">
        <label class="text-capitalize" for="details">Address</label>
        <textarea class="form-control" id="details" name="address" placeholder="Address"
        required><?php if(isset($project)): ?><?php echo e($project->address); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?></textarea>
    </div>
</div>

<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($project)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('projects.index')); ?>">Cancel</a>
</div>
<?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/projects/form.blade.php ENDPATH**/ ?>