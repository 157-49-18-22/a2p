<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="expense_category">Expense Category</label>
		<input type="text" class="form-control text-capitalize" id="expense_category" name="expense_category" placeholder="Expenses Category"
        value="<?php if(isset($expense)): ?><?php echo e($expense->expense_category); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" required>
    
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" name="payment_mode" onchange="otherSelect(event)" required>
            <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($payment_mode->id); ?>" <?php if(isset($expense)): ?> <?php if($payment_mode->id == $expense->payment_mode->id): ?> selected <?php endif; ?> <?php endif; ?>>
                    <?php echo e($payment_mode->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
		<div id="otherBox" style="visibility: hidden;">
		 <input name="cheque_no" type="text" placeholder="Enter Cheque no" class="form-control" /> 
		</div>
    </div>
	
	<!--div class="form-group col-sm-3 cheque_details" -->
       <div id="otherBox" style="visibility: hidden;">
		 <input name="cheque_no" type="text" placeholder="Enter Cheque no" class="form-control" /> 
		</div>
    <!--</div-->
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payee">Payee</label>
        <input type="text" class="form-control text-capitalize" id="payee" name="payee" placeholder="Payee name"
        value="<?php if(isset($expense)): ?><?php echo e($expense->payee); ?><?php else: ?><?php echo e(old('')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="amount_paid">Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control text-capitalize" id="amount_paid" name="amount_paid"
        value="<?php if(isset($expense)): ?><?php echo e($expense->amount_paid); ?><?php else: ?><?php echo e(old('amount_paid')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="date_of_payment">Date Of Payment</label>
        <input type="date" class="form-control" id="date_of_payment" name="date_of_payment"
        value="<?php if(isset($expense)): ?><?php echo e($expense->date_of_payment->format('Y-m-d')); ?><?php else: ?><?php echo e(old('date_of_payment')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Bill no</label>
        <input type="text" class="form-control" id="bill_no" name="bill_no" placeholder="Bill no"
        value="<?php if(isset($expense)): ?><?php echo e($expense->bill_no); ?><?php else: ?><?php echo e(old('bill_no')); ?><?php endif; ?>">
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Bill Attachment</label>
        <input type="file" class="form-control" id="bill_attachment" name="bill_attachment" >
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Office Address</label>
        <input type="text" class="form-control" id="address" name="address" placeholder="Address"
        value="<?php if(isset($expense)): ?><?php echo e($expense->address); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?>">
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Status</label>
        <select class="form-control js-example-basic-single" id="status" name="status" <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
		<option value="" 
		<?php if(!isset($expense->status)): ?> 
					<?php echo "selected";?>
					<?php endif; ?> 
					>Select</option>
                <option value="Pending" <?php if(isset($expense) && $expense->status == 'Pending'): ?> 
					<?php echo "selected";?>
					<?php endif; ?> >Pending</option>
                <option value="Paid" <?php if(isset($expense) && $expense->status == 'Paid'): ?> 
					<?php echo "selected";?>
					<?php endif; ?>>Paid</option>
                <option value="Rejected" <?php if(isset($expense) && $expense->status == 'Rejected'): ?> 
					<?php echo "selected";?>
					<?php endif; ?>>Rejected</option>
	
        </select>
    </div>
</div>

<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($expense)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('expenses.index')); ?>">Cancel</a>
</div>
<script>
function otherSelect(event) {
	//alert($( "#payment_mode  option:selected" ).text());
 var other = document.getElementById("otherBox");
 if ($( "#payment_mode  option:selected" ).text().trim() == "Cheque") {
 other.style.visibility = "visible";
 }
 else {
 other.style.visibility = "hidden";
 }
 }
</script><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/expenses/form.blade.php ENDPATH**/ ?>