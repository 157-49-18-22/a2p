<?php $__env->startSection('title', 'Project Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Project Details</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_create')): ?>
    <div id="<?php echo e($project->id); ?>" class="my-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_delete')): ?>
        <?php if(!$project->is_active): ?>
            <button class="entry-delete-btn btn btn-danger text-uppercase float-right ml-2">
                <i class="fas fa-trash-alt fa-fw"></i>
                <span class="big-btn-text">Delete This Project</span>
            </button>
        <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_edit')): ?>
        <a class="btn btn-primary text-uppercase float-right ml-2" href="<?php echo e(route('projects.edit', ['id' => $project->id])); ?>">
            <i class="fas fa-edit fa-fw"></i>
            <span class="big-btn-text">Edit This Project</span>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_create')): ?>
        <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('projects.create')); ?>">
            <i class="fas fa-plus fa-fw"></i>
            <span class="big-btn-text">Add New Project</span>
        </a>
        <?php endif; ?>
    </div>
    <br><br>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card px-3 py-2">
        <div class="row">
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>#</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($project->id); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Name</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($project->name); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Location</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($project->location); ?></span>
                    </li> 
					<li class="list-group-item">
                        <span>Address</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($project->address); ?></span>
                    </li>
					<li class="list-group-item">
                        <span>Brochure</span>:
                        <span class="pl-1 font-weight-bolder"><?php if(isset($project->brochure)): ?>
                                <a href="<?php echo e(url('/storage/galeryImages').'/'. $project->brochure); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo e($project->brochure); ?>

                                </a>
                            <?php else: ?>
                                <span class="text-secondary">
                                    N/A
                                </span>
                            <?php endif; ?></span>
                    </li>
                </ul>

            </div>
        </div>
    </div>

    
    <input type="hidden" id="deleteUrl<?php echo e($project->id); ?>" value="<?php echo e(route('projects.destroy', ['id' => $project->id])); ?>">
    <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('projects.index')); ?>">
    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
    <input type="hidden" id="deletedTitle" value="Deleted!">
    <input type="hidden" id="deletedMsg" value="The selected project was successfully deleted.">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/projects/show.blade.php ENDPATH**/ ?>