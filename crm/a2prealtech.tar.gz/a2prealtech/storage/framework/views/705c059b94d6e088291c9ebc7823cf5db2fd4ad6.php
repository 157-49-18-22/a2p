<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Date</label>
        <input type="text" class="form-control text-capitalize" id="name" name="date" placeholder="Full Name"
        value="<?php if(isset($enquiry)){$originalDate = $enquiry->created_at;
			echo $newDate = date("d-M-Y", strtotime($originalDate));} else{echo Date('d-M-Y');}?>">
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Name<span class="red">*</span></label>
        <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Full Name"
        value="<?php if(isset($enquiry)): ?><?php echo e($enquiry->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?> required>
    </div>
   
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="user@example.com"
        value="<?php if(isset($enquiry)): ?><?php echo e($enquiry->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>" <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">Contact Number<span class="red">*</span></label>
        <input type="tel" class="form-control" id="contact_no" name="contact_no" placeholder="+910123456789" maxlength="10" pattern="{0-9}" 
        value="<?php if(isset($enquiry)): ?><?php echo e($enquiry->contact_no); ?><?php else: ?><?php echo e(old('contact_no')); ?><?php endif; ?>" required <?php if(auth()->user()->hasRole('Admin') == false): ?>
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
    </div> 
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">Alternate Contact Number</label>
        <input type="tel" class="form-control" id="contact_no" name="a_contact_no" placeholder="+910123456789" maxlength="10" pattern="{0-9}" 
        value="<?php if(isset($enquiry)): ?><?php echo e($enquiry->a_contact_no); ?><?php else: ?><?php echo e(old('a_contact_no')); ?><?php endif; ?>"  <?php if(auth()->user()->hasRole('Admin') == false): ?>
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
    </div>
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="project">Project</label>
        <select class="form-control js-example-basic-single" id="project" name="project" <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
		<option value="" 
		<?php if(!isset($enquiry->project->id)): ?> 
					<?php echo "selected";?>
					<?php endif; ?> 
					>Select</option>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($project->id); ?>" <?php if(isset($enquiry->project->id)): ?> <?php if($project->id == $enquiry->project->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($project->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
        </select>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="configuration">Configuration</label>
        <select class="form-control js-example-basic-single" onchange="otherSelect(event)" id="configuration" name="configuration" <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?> >
		<option value="" 
		<?php if(!isset($enquiry->configuration->id)): ?> 
					<?php echo "selected";?>
					<?php endif; ?> 
					>Select</option>
            <?php $__currentLoopData = $configurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $configuration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($configuration->id); ?>" <?php if(isset($enquiry->configuration->id)): ?> <?php if($configuration->id == $enquiry->configuration->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($configuration->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
		<div id="otherBox" style="visibility: hidden;">
		 <input name="other_config" type="text" class="form-control" /> 
		</div>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="budget_range">Budget Range</label>
        <input type="tel" class="form-control" id="budget_range" name="budget_range" placeholder="Enter Budget" 
        value="<?php if(isset($enquiry)): ?><?php echo e($enquiry->budget_range); ?><?php else: ?><?php echo e(old('budget_range')); ?><?php endif; ?>" required <?php if(auth()->user()->hasRole('Admin') == false): ?>
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="enquiry_status">Status<span class="red">*</span></label>
        <select class="form-control js-example-basic-single" id="enquiry_status" name="enquiry_status" required <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?>>
            <?php $__currentLoopData = $enquiry_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status->id); ?>" <?php if(isset($enquiry)): ?> <?php if($status->id == $enquiry->enquiry_status->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($status->status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="row">
   <div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Address</label>
        <textarea class="form-control" id="subject" name="address" placeholder="Enter Address"
         <?php if(auth()->user()->hasRole('Admin') == false): ?> 
			<?php echo 'readonly' ;?>
		 <?php endif; ?>><?php if(isset($enquiry)): ?><?php echo e($enquiry->address); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?></textarea>
    </div>

    <?php if(auth()->user()->hasRole('Admin')): ?>
        <div class="form-group col-sm-3">
            <label class="text-capitalize" for="assigned_to">Assign To</label>
            <select class="form-control js-example-basic-single" id="assigned_to" name="assigned_to" >
				<option value="" <?php if(isset($enquiry->assignedTo) == ''): ?> 
					<?php echo "selected";?>
					<?php endif; ?> >Select</option>
			
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php if(isset($enquiry->assignedTo) && $user->id == $enquiry->assignedTo->id): ?> 
					<?php echo "selected";?> 
					<?php endif; ?> ><?php echo e($user->name); ?> - <?php echo e($user->no_of_enquiries_assigned); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
            </select>
        </div>
  
    <?php endif; ?>
	
	 <div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Remark</label>
        <textarea class="form-control" id="subject" name="subject" placeholder="Remark"
        ><?php if(isset($enquiry)): ?><?php echo e($enquiry->subject); ?><?php else: ?><?php echo e(old('subject')); ?><?php endif; ?></textarea>
    </div>
</div>

<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($enquiry)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(Url('/').'/enquiries/index'); ?>">Cancel</a>
</div>
<?php if(auth()->user()->hasRole('Admin') == false): ?>
	<style>
select[readonly].select2-hidden-accessible + .select2-container {
    pointer-events: none;
    touch-action: none;

    .select2-selection {
        background: #eee;
        box-shadow: none;
    }

    .select2-selection__arrow, select[readonly].select2-hidden-accessible + .select2-container .select2-selection__clear {
        display: none;
    }
	
}

</style>
<?php endif; ?>
<style>
.red{
		color:#ff0000;
	}
</style>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>

<script>
		
jQuery(function(){
  jQuery("input[name='contact_no']").on('input', function (e) {
    jQuery(this).val($(this).val().replace(/[^0-9]/g, ''));
  });
});
function otherSelect(event) {
	
 var other = document.getElementById("otherBox");
 if ($( "#configuration  option:selected" ).text() == "Other") {
 other.style.visibility = "visible";
 }
 else {
 other.style.visibility = "hidden";
 }
 }
</script><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/enquiries/form.blade.php ENDPATH**/ ?>