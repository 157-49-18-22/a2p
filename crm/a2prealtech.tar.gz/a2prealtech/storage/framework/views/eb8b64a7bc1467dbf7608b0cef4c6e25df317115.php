<?php $__env->startSection('title', 'My Account'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>My Account</h1>
    <?php if($errors->any()): ?>
        <div class="border border-danger text-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="border border-danger text-danger">
            <ul>
                <li><?php echo e(Session::get('success')); ?></li>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <form method="post" action="<?php echo e(route('myaccount.update', ['id' => auth()->user()->id])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="name">Name</label>
                    <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Full Name"
                    value="<?php echo e(auth()->user()->name); ?>" required readonly>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="username@example.com"
                    value="<?php echo e(auth()->user()->email); ?>" required readonly>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="photo">Photo</label>
                    <input type="file" class="form-control" id="photo" name="photo" accept="image/png, image/jpeg" disabled>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="photo">Current Photo</label>
                    <?php if(isset(auth()->user()->photo_url)): ?>
                        <img height="42" width="42" src="<?php echo e(asset('storage/profile_picture/' . auth()->user()->photo_url)); ?>" alt='profile photo'
                        class="inline w-9 h-9 pr-1" />
                    <?php else: ?>
                        <span class="border border-red-500">
                            No photo provided.
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="border border-danger text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <input type="submit" class="btn btn-success" value="Update">
                <a class="btn btn-danger ml-3" href="<?php echo e(route('dashboard.index')); ?>">Cancel</a>
            </div>
        </form>

        <form method="post" action="<?php echo e(route('myaccount.changepassword', ['id' => auth()->user()->id])); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="current_password">Current Password</label>
                    <input type="password" class="form-control" id="current_password" name="current_password"
                    placeholder="Current password" required>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="password">New Password</label>
                    <input type="password" class="form-control" id="password" name="password"
                    placeholder="New password" required>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="password_confirmation">Confirm New Password</label>
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation"
                    placeholder="Confirm new password" required>
                </div>
            </div>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="border border-danger text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <input type="submit" class="btn btn-success" value="Update">
                <a class="btn btn-danger ml-3" href="<?php echo e(route('dashboard.index')); ?>">Cancel</a>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/myaccount/index.blade.php ENDPATH**/ ?>