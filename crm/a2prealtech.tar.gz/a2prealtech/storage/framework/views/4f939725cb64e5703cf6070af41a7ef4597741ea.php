<?php $__env->startSection('title', 'Add New Project'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add New Project</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('projects.store')); ?>" enctype="multipart/form-data">
        <?php echo $__env->make('projects.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/projects/create.blade.php ENDPATH**/ ?>