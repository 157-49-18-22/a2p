<?php $__env->startSection('title', 'Import Leads'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Import Leads</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(route('enquiries.store_import')); ?>" enctype= "multipart/form-data">
	  <?php echo csrf_field(); ?>

       <div class="row">
			<div class="form-group col-sm-9">
				<label class="text-capitalize" for="name">Upload File</label>
				<p>For uploading leads please following the format of sample Leads file. <a href="<?php echo e(url('/').'/storage/galeryImages/leads.csv'); ?>" download="leads.csv">Click here </a> to download the sample file</p>
				<input type="file" class="form-control text-capitalize" id="name" name="import_file" required>
			</div>
		</div>
		<div class="form-group">
			<input type="submit" class="btn btn-success" value="Import">
		</div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/s2.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/enquiries/import.blade.php ENDPATH**/ ?>