<?php $__env->startSection('title', 'Client Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Client Details</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_create')): ?>
    <div id="<?php echo e($client->id); ?>" class="my-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_delete')): ?>
        <?php if(!$client->is_active): ?>
            <button class="entry-delete-btn btn btn-danger text-uppercase float-right ml-2">
                <i class="fas fa-trash-alt fa-fw"></i>
                <span class="big-btn-text">Delete This Client</span>
            </button>
        <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_edit')): ?>
        <a class="btn btn-primary text-uppercase float-right ml-2" href="<?php echo e(route('clients.edit', ['id' => $client->id])); ?>">
            <i class="fas fa-edit fa-fw"></i>
            <span class="big-btn-text">Edit This client</span>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_create')): ?>
        <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('clients.create')); ?>">
            <i class="fas fa-plus fa-fw"></i>
            <span class="big-btn-text">Add New client</span>
        </a>
        <?php endif; ?>
    </div>
    <br><br>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card px-3 py-2">
        <div class="row">
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>Name</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($client->name); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Contact No.</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($client->contact_no); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Alternate Contact No.</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($client->a_contact_no); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Email</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($client->email); ?></span>
                    </li>
                </ul>

            </div>
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>Subject</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->subject); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Remark</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->remark); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Rating</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php for($i = 0; $i < $client->rating; $i++): ?>
                                &starf;
                            <?php endfor; ?>
                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Status</span>:
                        <span class="pl-1 font-weight-bolder <?php echo e(App\Lancer\Utilities::getClientStatusStyle($client->is_active)); ?>">
                            <?php echo e(App\Lancer\Utilities::getClientStatus($client->is_active)); ?>

                        </span>
                    </li>
                </ul>

            </div>
        </div>

    </div>

    
    <div class="card px-3 py-2 mb-5">
    <h5>Booking Details:</h5>
        <div class="row">
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>Project</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->project->name); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Configuration</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->configuration->name); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Carpet Area</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->carpet_area); ?> Sq. Ft.
                        </span>
                    </li>
					<li class="list-group-item">
                        <span>Unit Number</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->unit_no); ?> 
                        </span>
                    </li><li class="list-group-item">
                        <span>Floor Number</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->floor_no); ?> 
                        </span>
                    </li>
                </ul>

            </div>
            <div class="col-6">
                <ul class="list-group">
					<li class="list-group-item">
                        <span>Tower Number</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->tower_no); ?> 
                        </span>
                    </li><li class="list-group-item">
                        <span>Actual Amount</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($client->actual_amount); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Booking Amount</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($client->booking_amount); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Agreement Value</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($client->agreement_value); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Payment Mode</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($client->payment_mode->name); ?>

                        </span>
                    </li>
					
                </ul>

            </div>
        </div>

    </div>

    
    <input type="hidden" id="deleteUrl<?php echo e($client->id); ?>" value="<?php echo e(route('clients.destroy', ['id' => $client->id])); ?>">
    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
    <input type="hidden" id="deletedTitle" value="Deleted!">
    <input type="hidden" id="deletedMsg" value="Your request has been successfully completed.">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/clients/show.blade.php ENDPATH**/ ?>