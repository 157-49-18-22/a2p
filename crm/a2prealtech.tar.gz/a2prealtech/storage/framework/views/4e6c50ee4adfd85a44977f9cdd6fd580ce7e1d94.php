<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Name<span class="red">*</span></label>
        <input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Full Name"
        value="<?php if(isset($user)): ?><?php echo e($user->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="email">Email<span class="red">*</span></label>
        <input type="email" class="form-control" id="email" name="email" placeholder="username@example.com"
        value="<?php if(isset($user)): ?><?php echo e($user->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="photo">Photo</label>
        <input type="file" class="form-control" id="photo" name="photo" accept="image/png, image/jpeg">
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="photo">Current Photo</label>
        <?php if(isset($user->photo_url)): ?>
            <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'. $user->photo_url); ?>" alt='profile photo'
            class="inline w-9 h-9 pr-1" />
        <?php else: ?>
            <span class="border border-red-500">
                No photo provided.
            </span>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="role">Role<span class="red">*</span></label>
        <select class="form-control js-example-basic-single" id="role" name="role" required>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php if(isset($user)): ?> <?php if($user->roles->first()->id == $role->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
	<?php if(!isset($user)): ?>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="password">Password<span class="red">*</span></label>
        <input type="password" class="form-control" id="password" value="<?php if(isset($user->password)): ?><?php echo e($user->password); ?>else<?php echo e(''); ?><?php endif; ?>" name="password"
        placeholder="Password" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="password_confirmation">Confirm Password<span class="red">*</span></label>
        <input type="password" class="form-control" value="<?php if(isset($user->password)): ?><?php echo e($user->password); ?>else<?php echo e(''); ?><?php endif; ?>" id="password_confirmation" name="password_confirmation"
        placeholder="Confirm password" required>
    </div>
	<?php endif; ?>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="phone">Phone<span class="red">*</span></label>
        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone number" maxlength="10" pattern="{0-9}" 
        value="<?php if(isset($user)): ?><?php echo e($user->phone); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" required> 
    </div>
    <div class="form-group col-sm-6">
        <label class="text-capitalize" for="address">Address</label>
        <textarea name="address" class="form-control"><?php if(isset($user)): ?><?php echo e($user->address); ?><?php else: ?><?php echo e(''); ?><?php endif; ?></textarea>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="aadhar">Aadhar</label>
        <input type="file" class="form-control" id="aadhar" name="aadhar">
    </div>
    <div class="form-group col-sm-6">
        <label class="text-capitalize" for="aadhar">Aadhar</label>
        <?php if(isset($user->aadhar)): ?> 
            <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'. $user->aadhar); ?>" alt='profile photo'
            class="inline w-9 h-9 pr-1" />
        <?php else: ?>
            <span class="border border-red-500">
                No photo provided.
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="pancard">Pan Card</label>
        <input type="file" class="form-control" id="pancard" name="pancard">
    </div>
    <div class="form-group col-sm-6">
        <label class="text-capitalize" for="pancard">Pan Card</label>
        <?php if(isset($user->pancard)): ?>
            <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'. $user->pancard); ?>" alt='profile photo'
            class="inline w-9 h-9 pr-1" />
        <?php else: ?>
            <span class="border border-red-500">
                No photo provided.
            </span>
        <?php endif; ?>
    </div>
</div>
<div class="row">
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="role">Export Leads<span class="red">*</span></label>
        <select class="form-control js-example-basic-single" id="role" name="export" required>                
                <option value="0" <?php if(isset($user) && $user->export == 0): ?>
				<?php echo "selected";?> <?php endif; ?>> No</option>
				<option value="1" <?php if(isset($user) && $user->export == 1): ?>
				<?php echo "selected";?> <?php endif; ?>> Yes</option>
        </select>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="role">Status<span class="red">*</span></label>
        <select class="form-control js-example-basic-single" id="role" name="status" required>                
                <option value="0" <?php if(isset($user) && $user->status == 0): ?>
				<?php echo "selected";?> <?php endif; ?>> InActive</option>
				<option value="1" <?php if(isset($user) && $user->status == 1): ?>
				<?php echo "selected";?> <?php endif; ?>> Active</option>
        </select>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="phone">Location<span class="red">*</span></label>
        <input type="text" class="form-control" id="location" name="location" placeholder="Enter location"  
        value="<?php if(isset($user->location)): ?><?php echo e($user->location); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" required> 
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="phone">Salary<span class="red">*</span></label>
        <input type="text" class="form-control" id="salary" name="salary" placeholder="Enter Salary of user"  
        value="<?php if(isset($user->salary)): ?><?php echo e($user->salary); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" required> 
    </div>
   
</div>
<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($due)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('useraccounts.index')); ?>">Cancel</a>
</div>
<style>
.red{
	color:#ff0000;
}
</style>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>

<script>
		jQuery(function(){
  jQuery("input[name='phone']").on('input', function (e) {
    jQuery(this).val($(this).val().replace(/[^0-9]/g, ''));
  });
});
</script><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/useraccounts/form.blade.php ENDPATH**/ ?>