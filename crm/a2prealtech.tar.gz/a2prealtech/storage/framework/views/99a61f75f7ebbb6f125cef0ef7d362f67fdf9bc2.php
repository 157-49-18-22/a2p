<?php $__env->startSection('title', 'Leads'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Leads</h1>
    <?php if($errors->any()): ?>
        <div class="border border-danger text-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="border border-danger text-danger">
            <ul>
                <li><?php echo e(Session::get('success')); ?></li>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <form method="post" action="" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
			 <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="password">Admin Verification code</label>
                    <input type="text" class="form-control" id="password" name="admin_code"
                    placeholder="Admin code" required>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="password_confirmation">Verification code</label>
                    <input type="text" class="form-control" id="password_confirmation" name="code"
                    placeholder="Verification code" required>
                </div>
		 <div class="form-group">
				<input type="hidden" name="file_type" value="<?php echo e($file_type); ?>">
                <input type="submit" class="btn btn-success" value="Submit">
                <a class="btn btn-danger ml-3" href="<?php echo e(route('dashboard.index')); ?>">Cancel</a>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/enquiries/2fa.blade.php ENDPATH**/ ?>