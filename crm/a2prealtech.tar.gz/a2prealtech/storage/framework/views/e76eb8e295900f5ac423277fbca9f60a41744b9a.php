<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-3">
            <div class="card px-3 py-1 bg-primary text-white" style="height: 120px;">
                <span class="ml-auto">Conversion Ratio</span>
                <div class="row mt-4">
                    <span style="font-size: 40px; opacity: 0.40;">
                        <i class="fas fa-fw fa-divide"></i>
                    </span>
                    <span class="ml-auto" style="font-size: 40px;">
                        <?php echo e($conversion_ratio); ?>

                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card px-3 py-1 bg-success text-white" style="height: 120px;">
                <span class="ml-auto">Monthly Earnings</span>
                <div class="row mt-4">
                    <span style="font-size: 40px; opacity: 0.40;">
                        <i class="fas fa-fw fa-piggy-bank"></i>
                    </span>
                    <span class="ml-auto" style="font-size: 40px;">
                        <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($amount_earned_this_month); ?>

                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card px-3 py-1 bg-danger text-white" style="height: 120px;">
                <span class="ml-auto">Monthly Expenses</span>
                <div class="row mt-4">
                    <span style="font-size: 40px; opacity: 0.40;">
                        <i class="fas fa-fw fa-money-bill"></i>
                    </span>
                    <span class="ml-auto" style="font-size: 40px;">
                        <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($expense_paid_this_month); ?>

                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card px-3 py-1 bg-warning text-white" style="height: 120px;">
                <span class="ml-auto">Total Due</span>
                <div class="row mt-4">
                    <span style="font-size: 40px; opacity: 0.40;">
                        <i class="fas fa-fw fa-cash-register"></i>
                    </span>
                    <span class="ml-auto" style="font-size: 40px;">
                        <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($total_due); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <div class="card px-3 py-2" style="height: 400px;">
                <h6>Followups</h6>
                <ul class="nav nav-tabs" id="followupsTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="today-tab" data-toggle="tab" href="#today" role="tab" aria-controls="today" aria-selected="true">Today</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="upcoming-tab" data-toggle="tab" href="#upcoming" role="tab" aria-controls="upcoming" aria-selected="true">Upcoming</a>
                    </li>
                </ul>

                <div class="tab-content" id="followupsTabContent">
                    <div class="tab-pane fade show active" id="today" role="tabpanel" aria-labelledby="today-tab">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Remark</th>
                                    <th scope="col">Time</th>
                                    <th scope="col">View</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($followups_today) > 0): ?>
                                    <?php $__currentLoopData = $followups_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($followup->enquiry->name); ?></td>
                                            <td><?php echo e($followup->remark); ?></td>
                                            <td><?php echo e($followup->date_time->format('h:i a')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('enquiries.show', ['id' => $followup->enquiry->id])); ?>" class="btn btn-primary btn-sm">VIEW</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <th colspan="4" class="text-center">
                                                No followups found
                                            </th>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($followups_today->links()); ?>

                        </div>

                    </div>
                    <div class="tab-pane fade" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Remark</th>
                                    <th scope="col">Datetime</th>
                                    <th scope="col">View</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($followups_upcoming) > 0): ?>
                                    <?php $__currentLoopData = $followups_upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($followup->enquiry->name); ?></td>
                                            <td><?php echo e($followup->remark); ?></td>
                                            <td><?php echo e($followup->date_time->format('d-M-Y @ h:i a')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('enquiries.show', ['id' => $followup->enquiry->id])); ?>" class="btn btn-primary btn-sm">VIEW</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <th colspan="4" class="text-center">
                                            No followups found
                                        </th>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($followups_upcoming->links()); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="col-sm-6">
            <div class="card px-3 py-2" style="height: 400px;">
                <div class="clearfix">
                    <h6 class="float-left">Dues</h6>
                    <a href="<?php echo e(route('dues.index')); ?>" class="btn btn-primary btn-sm float-right">VIEW ALL</a>
                </div>
                <ul class="nav nav-tabs" id="duesTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="dues-upcoming-tab" data-toggle="tab" href="#dues-upcoming" role="tab" aria-controls="dues-upcoming" aria-selected="true">Upcoming</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="dues-outstanding-tab" data-toggle="tab" href="#dues-outstanding" role="tab" aria-controls="dues-outstanding" aria-selected="true">Outstanding</a>
                    </li>
                </ul>

                <div class="tab-content" id="duesTabContent">
                    <div class="tab-pane fade show active" id="dues-upcoming" role="tabpanel" aria-labelledby="dues-upcoming-tab">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">Payer</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Remark</th>
                                    <th scope="col">Due Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($dues_upcoming) > 0): ?>
                                    <?php $__currentLoopData = $dues_upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($due->payer); ?></td>
                                            <td><?php echo e($due->amount); ?></td>
                                            <td><?php echo e($due->remark); ?></td>
                                            <td><?php echo e($due->due_date->format('d-M-Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <th colspan="4" class="text-center">
                                            No dues found
                                        </th>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($dues_upcoming->links()); ?>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="dues-outstanding" role="tabpanel" aria-labelledby="dues-outstanding-tab">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Remark</th>
                                    <th scope="col">Due Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($dues_outstanding) > 0): ?>
                                    <?php $__currentLoopData = $dues_outstanding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($due->payer); ?></td>
                                            <td><?php echo e($due->amount); ?></td>
                                            <td><?php echo e($due->remark); ?></td>
                                            <td><?php echo e($due->due_date->format('d-M-Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <th colspan="4" class="text-center">
                                            No dues found
                                        </th>
                                    </tr>
                                <?php endif; ?>

                                </tbody>
                            </table>
                            <?php echo e($dues_outstanding->links()); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/dashboard/index.blade.php ENDPATH**/ ?>