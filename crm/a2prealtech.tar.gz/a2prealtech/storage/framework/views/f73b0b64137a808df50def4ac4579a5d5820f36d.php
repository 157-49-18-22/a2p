<?php $__env->startSection('title', 'Edit Lead'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Lead</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(route('enquiries.update', ['id' => $enquiry->id])); ?>">
        <?php echo $__env->make('enquiries.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>


<div class="remarks">
<h3>Remarks History</h3>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Remark</th>
      <th scope="col">Added By</th>
      <th scope="col">Added at</th>
    </tr>
  </thead>
  <tbody>
  <?php if($remarks): ?>
	  <?php $i= 1;?>
	  <?php $__currentLoopData = $remarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($i); ?></th>
      <td><?php echo e($r->remarks); ?></td>
      <td><?php echo e($r->name); ?></td>
      <td><?php echo e($r->created_by); ?></td>
    </tr>
	<?php $i++;?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<tr>
	</tr>
	<?php endif; ?>
   </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/s2.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/enquiries/edit.blade.php ENDPATH**/ ?>