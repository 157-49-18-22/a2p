<?php $__env->startSection('title', 'All Users'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>All Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('useraccounts.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add New User</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Name</th>
                        <th class="text-uppercase" scope="col">Email</th>
                        <th class="text-uppercase" scope="col">Photo</th>
                        <th class="text-uppercase" scope="col">Role</th>
                        <th class="text-uppercase" scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php if(isset($user->photo_url)): ?>
                                <a href="<?php echo e(url('/storage/galeryImages').'/'. $user->photo_url); ?>" target="_blank" rel="noopener noreferrer">
                                    <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'. $user->photo_url); ?>" alt='profile photo'
                                    class="img-thumbnail" />
                                </a>
                            <?php else: ?>
                                <span class="text-secondary">
                                    <i class="fas fa-user-circle fa-lg"></i>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(implode(', ', $user->roles->pluck('name')->toArray())); ?></td>
                        <td>
                            <div class="dropdown">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-boundary="viewport">
                                    ACTIONS
                                </a>
                                <div id="<?php echo e($user->id); ?>" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item text-primary"
                                        href="<?php echo e(route('useraccounts.show', ['id' => $user->id])); ?>">View</a>
                                    <?php if($user->id !== auth()->user()->id): ?>
                                    <a class="dropdown-item text-primary"
                                        href="<?php echo e(route('useraccounts.edit', ['id' => $user->id])); ?>">Edit</a>
                                    <div class="dropdown-divider"></div>
                                    <a role="button" class="entry-delete-btn dropdown-item text-danger" style=""href="<?php echo e(route('useraccounts.destroy', ['id' => $user->id])); ?>">
                                        Delete
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <input type="hidden" id="deleteUrl<?php echo e($user->id); ?>" value="<?php echo e(route('useraccounts.destroy', ['id' => $user->id])); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
					 
    <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('useraccounts.index')); ?>">
    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
    <input type="hidden" id="deletedTitle" value="Deleted!">
    <input type="hidden" id="deletedMsg" value="The selected user was successfully deleted.">
                   

                </tbody>
            </table>
            <?php if(count($users) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">
            <?php echo e($users->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/useraccounts/index.blade.php ENDPATH**/ ?>