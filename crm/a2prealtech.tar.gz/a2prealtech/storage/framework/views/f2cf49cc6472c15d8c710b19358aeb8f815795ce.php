<?php $__env->startSection('title', 'Lead Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lead Details</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_create')): ?>
    <div id="<?php echo e($enquiry->id); ?>" class="my-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_delete')): ?>
        <button class="entry-delete-btn btn btn-danger text-uppercase float-right ml-2">
            <i class="fas fa-trash-alt fa-fw"></i>
            <span class="big-btn-text">Mark This Lead As Lost</span>
        </button>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_edit')): ?>
        <?php if($enquiry->enquiry_status->id < 4): ?>
        <a class="btn btn-primary text-uppercase float-right ml-2" href="<?php echo e(route('enquiries.edit', ['id' => $enquiry->id])); ?>">
            <i class="fas fa-edit fa-fw"></i>
            <span class="big-btn-text">Edit This Lead</span>
        </a>
        <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_create')): ?>
        <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('enquiries.create')); ?>">
            <i class="fas fa-plus fa-fw"></i>
            <span class="big-btn-text">Add New Lead</span>
        </a>
        <?php endif; ?>
    </div>
    <br><br>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="card px-3 py-2">
        <div class="row">
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>#</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($enquiry->id); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Name</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($enquiry->name); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Contact No.</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($enquiry->contact_no); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Alternate Contact Number</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($enquiry->a_contact_no); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Email</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($enquiry->email); ?></span>
                    </li>
					<li class="list-group-item">
                        <span>Address</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($enquiry->address); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Remarks</span>:
                        <span class="pl-1 font-weight-bolder">
                           <?php if(isset($remarks->remarks)): ?> <?php echo e($remarks->remarks); ?> else <?php echo e(''); ?> <?php endif; ?>
                        </span>
                    </li>
                </ul>

            </div>
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>Project</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($enquiry->project->name)): ?>
                            <?php echo e($enquiry->project->name); ?>

                            <?php endif; ?>
                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Configuration</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($enquiry->configuration->name)): ?>
                            <?php echo e($enquiry->configuration->name); ?>

                            <?php endif; ?>
                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Budget</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($enquiry->budget_range)): ?>
                            <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($enquiry->budget_range); ?>

                            <?php endif; ?>
                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Status</span>:
						<?php if($enquiry->enquiry_status): ?>
                        <span class="pl-1 font-weight-bolder <?php echo e(App\Lancer\Utilities::getEnquiryStatusStyle($enquiry->enquiry_status->id)); ?>">
                            <?php echo e($enquiry->enquiry_status->status); ?>

                        </span>
						<?php endif; ?>
                    </li>
                    <li class="list-group-item">
                        <span>Assigned To</span>:
						<?php if($enquiry->assignedTo): ?>
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($enquiry->assignedTo->name); ?>

                        </span>
						<?php endif; ?>
                    </li>
                </ul>

            </div>
        </div>

    </div>

    
    <div class="card px-3 py-2">
        <h5>Update Status Or Project</h5>
        <form method="post" action="<?php echo e(route('enquiries.updateStatus', ['id' => $enquiry->id])); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="enquiry_status">Status</label>
                    <select class="form-control js-example-basic-single" id="enquiry_status" name="enquiry_status" <?php if($enquiry->enquiry_status->id > 3): ?> disabled <?php endif; ?> required>
                        <?php $__currentLoopData = $enquiry_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->id); ?>" <?php if(isset($enquiry)): ?> <?php if($status->id == $enquiry->enquiry_status->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($status->status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-sm-3">
                    <label class="text-capitalize" for="project">Project</label>
                    <select class="form-control js-example-basic-single" id="project" name="project" <?php if($enquiry->enquiry_status->id > 3): ?> disabled <?php endif; ?> required>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>" <?php if(isset($enquiry->project->id)): ?> <?php if($project->id == $enquiry->project->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <?php if($enquiry->enquiry_status->id < 4): ?>
                    <input type="submit" class="btn btn-success" value="Update">
                    <a class="btn btn-danger ml-3" href="">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>


    
    <div class="card px-3 py-2">
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('followup_create')): ?>
            <?php if($enquiry->enquiry_status->id < 4): ?>
                <button class="add-followup-btn btn btn-success text-uppercase float-right">
                    <i class="fas fa-fw fa-plus"></i> Add Follow Up
                </button>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="container">
            <h5>Follow Ups</h5>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div id="content">
                                <ul class="timeline">
                                    <?php $__currentLoopData = $followups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li id="<?php echo e($followup->id); ?>" class="event" data-date="<?php echo e($followup->date_time->format('d-M-Y - h:i a')); ?>">
                                        <?php if($followup->outcome != null): ?>
                                            <h3><b>Outcome: <?php echo e($followup->outcome ?? 'None'); ?></b></h3>
                                        <?php endif; ?>
                                        <p><?php echo e($followup->remark); ?></p>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('followup_edit')): ?>
                                        <?php if($enquiry->enquiry_status->id < 4): ?>
                                        <button type="button" class="follow-up-edit-btn btn btn-primary">
                                            <i class="fas fa-edit fa-fw"></i>
                                        </button>
                                        <?php endif; ?>
                                        <input type="hidden" id="editfollowupurl<?php echo e($followup->id); ?>" value="<?php echo e(route('followups.update', ['id' => $followup->id])); ?>">
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('followup_delete')): ?>
                                        <button type="button" class="follow-up-delete-btn btn btn-danger ml-2">
                                            <i class="fas fa-trash-alt fa-fw"></i>
                                        </button>
                                        <input type="hidden" id="deletefollowupurl<?php echo e($followup->id); ?>" value="<?php echo e(route('followups.destroy', ['id' => $followup->id])); ?>">
                                        <?php endif; ?>
                                    </li>

                                    
                                    <input type="hidden" id="date_time<?php echo e($followup->id); ?>"
                                    value="<?php echo e($followup->date_time->format('Y-m-d')); ?>T<?php echo e($followup->date_time->format('H:m')); ?>">
                                    <input type="hidden" id="remark<?php echo e($followup->id); ?>" value="<?php echo e($followup->remark); ?>">
                                    <input type="hidden" id="outcome<?php echo e($followup->id); ?>" value="<?php echo e($followup->outcome); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <input type="hidden" id="deleteUrl<?php echo e($enquiry->id); ?>" value="<?php echo e(route('enquiries.destroy', ['id' => $enquiry->id])); ?>">
    <input type="hidden" id="deletedBtnText" value="Yes, mark it!">
    <input type="hidden" id="deletedTitle" value="Marked as lost!">
    <input type="hidden" id="deletedMsg" value="The selected enquiry has been successfully marked as lost.">

    
    <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('enquiries.index')); ?>">

    
    <input type="hidden" id="addfollowupurl" value="<?php echo e(route('followups.store')); ?>">
    <input type="hidden" id="enquiryid" value="<?php echo e($enquiry->id); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/timeline.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/enquiry_lost.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/followups_swal.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/enquiries/show.blade.php ENDPATH**/ ?>