<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Transactions</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Details</th>
                        <th class="text-uppercase" scope="col">Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transaction->id); ?></td>
                        <td><?php echo e($transaction->details); ?></td>
                        <td><?php echo e($transaction->created_at->format('d-M-Y')); ?> at <?php echo e($transaction->created_at->format('g:i A')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if(count($transactions) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">
            <?php echo e($transactions->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/transactions/index.blade.php ENDPATH**/ ?>