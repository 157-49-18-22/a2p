<?php $__env->startSection('adminlte_css_pre'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('auth_header', __('Enter Verification Code')); ?>

<?php $__env->startSection('auth_body'); ?>
    <form action="" method="post">
        <?php echo e(csrf_field()); ?>


        
        <div class="input-group mb-3">
            <input type="text" name="code" class="form-control "
                   value="" placeholder="Enter Code" autofocus>
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-password <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
			<?php //echo "<pre>";print_r($errors->first('code'));echo "</pre>";?>
             <?php if($errors->first('code')): ?>
                <div class="invalid-feedback has_error">
                    <strong><?php echo e($errors->first('code')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

       

        
        <div class="row">
            
            <div class="col-5">
                <button type=submit class="btn btn-block <?php echo e(config('adminlte.classes_auth_btn', 'btn-flat btn-primary')); ?>">
                    <span class="fas fa-sign-in-alt"></span>
                    Verify
                </button>
            </div>
        </div>

    </form>
<style>
.has_error{
	display:block !important;
}
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/signin/2fa.blade.php ENDPATH**/ ?>