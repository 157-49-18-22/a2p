<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<h4>Invoice Details</h4>
<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Bill No/Invoice No</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="bill_no" name="bill_no" placeholder="Enter Bill No"
            value="<?php echo e($invoice->bill_no); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="bill_no" name="bill_no" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->bill_no); ?><?php else: ?><?php echo e(old('bill_no')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Bill/Invoice Raised Date</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="bill_date" name="bill_date" placeholder="Enter Bill date"
            value="<?php echo e($invoice->bill_date); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="bill_date" name="bill_date" placeholder="Enter Bill date"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->bill_date); ?><?php else: ?><?php echo e(date('Y/m/d')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>

	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Type of Bill</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="bill_type" name="bill_type" placeholder="Enter Bill Type"
            value="<?php echo e($invoice->bill_type); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="bill_type" name="bill_type" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->bill_type); ?><?php else: ?><?php echo e(old('bill_type')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="name">Customer Name</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="customer_name" name="customer_name" placeholder="Enter Customer Name"
            value="<?php echo e($invoice->customer_name); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="customer_name" name="customer_name" placeholder="Enter Customer Name"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->customer_name); ?><?php else: ?><?php echo e(old('customer_name')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Company/Developer</label>
        <?php if(isset($invoice)): ?>
            <textarea class="form-control" id="company_developer" name="company_developer" placeholder="Enter Company/Developer"
            ><?php echo e($invoice->company_developer); ?></textarea>
        <?php else: ?>
            <textarea class="form-control" id="subject" name="company_developer" placeholder="Enter Company/Developer"
            ><?php if(isset($invoice)): ?><?php echo e($invoice->subject); ?><?php else: ?><?php echo e(old('company_developer')); ?><?php endif; ?></textarea>
        <?php endif; ?>
    </div>
   
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Address of Company</label>
        <?php if(isset($invoice)): ?>
            <textarea class="form-control" id="company_address" name="company_address" placeholder="Enter Company Address"
            ><?php echo e($invoice->company_address); ?></textarea>
        <?php else: ?>
            <textarea class="form-control" id="subject" name="company_address" placeholder="Enter Company Address"
            ><?php if(isset($invoice)): ?><?php echo e($invoice->company_address); ?><?php else: ?><?php echo e(old('company_address')); ?><?php endif; ?></textarea>
        <?php endif; ?>
    </div>

    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">Property Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="number" class="form-control" id="property_amount" name="property_amount" placeholder="Enter Amount of Property"  pattern="{0-9}" 
            value="<?php echo e($invoice->property_amount); ?>" required>
        <?php else: ?>
            <input type="tel" class="form-control" id="property_amount" name="property_amount" placeholder="Enter Amount of Property" pattern="{0-9}" 
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->property_amount); ?><?php else: ?><?php echo e(old('property_amount')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">GST</label>
        <?php if(isset($invoice)): ?>
            <input type="number" class="form-control" id="gst" name="gst" placeholder="Enter Amount of GST"  pattern="{0-9}" 
            value="<?php echo e($invoice->gst); ?>" required>
        <?php else: ?>
            <input type="tel" class="form-control" id="gst" name="gst" placeholder="Enter Amount of GST" pattern="{0-9}" 
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->gst); ?><?php else: ?><?php echo e(old('gst')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="contact_no">Total Amount Raised to Developer</label>
        <?php if(isset($invoice)): ?>
            <input type="number" class="form-control" id="amount_for_developer" name="amount_for_developer" placeholder="Enter Amount Raised to Developer"  pattern="{0-9}" 
            value="<?php echo e($invoice->amount_for_developer); ?>" required>
        <?php else: ?>
            <input type="number" class="form-control" id="amount_for_developer" name="amount_for_developer" placeholder="Enter Amount Raised to Developer" pattern="{0-9}" 
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->amount_for_developer); ?><?php else: ?><?php echo e(old('amount_for_developer')); ?><?php endif; ?>" required>
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-3">
		<label class="text-capitalize" for="name">GST status</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="gst_status" name="gst_status" placeholder="Enter GST Status"
            value="<?php echo e($invoice->gst_status); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="gst_status" name="gst_status" placeholder="Enter GST Status"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->gst_status); ?><?php else: ?><?php echo e(old('gst_status')); ?><?php endif; ?>" required>
        <?php endif; ?>
	</div>
	<div class="form-group col-sm-3">
		<label class="text-capitalize" for="name">Bill status</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="bill_status" name="bill_status" placeholder="Enter Bill Status"
            value="<?php echo e($invoice->bill_status); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="bill_status" name="bill_status" placeholder="Enter Bill Status"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->bill_status); ?><?php else: ?><?php echo e(old('bill_status')); ?><?php endif; ?>" required>
        <?php endif; ?>
	</div>
	<div class="form-group col-sm-3">
		<label class="text-capitalize" for="name">TDS Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="tds" name="tds" placeholder="Enter TDS amount"
            value="<?php echo e($invoice->tds); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="tds" name="tds" placeholder="Enter TDS Amount"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->tds); ?><?php else: ?><?php echo e(old('tds')); ?><?php endif; ?>" required>
        <?php endif; ?>
	</div>
	<div class="form-group col-sm-3">
		<label class="text-capitalize" for="name">Amount after TDS</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="amount_after_tds" name="amount_after_tds" placeholder="Property Amount after TDS "
            value="<?php echo e($invoice->amount_after_tds); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="amount_after_tds" name="amount_after_tds" placeholder="Property Amount after TDS"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->amount_after_tds); ?><?php else: ?><?php echo e(old('amount_after_tds')); ?><?php endif; ?>" required>
        <?php endif; ?>
	</div>
	
	<div class="form-group col-sm-3">
		<label class="text-capitalize" for="name">After customer Pass on</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="after_customer_passon" name="after_customer_passon" placeholder="Property Amount After customer Pass on"
            value="<?php echo e($invoice->after_customer_passon); ?>" required>
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="after_customer_passon" name="after_customer_passon" placeholder="Property Amount After customer Pass on"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->after_customer_passon); ?><?php else: ?><?php echo e(old('after_customer_passon')); ?><?php endif; ?>" required>
        <?php endif; ?>
	</div>
	<div class="form-group col-sm-3">
        <label class="text-capitalize" for="subject">Remarks(if any)</label>
        <?php if(isset($invoice)): ?>
            <textarea class="form-control" id="remarks" name="remarks" placeholder="Enter Remraks"
            ><?php echo e($invoice->remarks); ?></textarea>
        <?php else: ?>
            <textarea class="form-control" id="subject" name="remarks" placeholder="Enter Remarks"
            ><?php if(isset($invoice)): ?><?php echo e($invoice->remarks); ?><?php else: ?><?php echo e(old('remarks')); ?><?php endif; ?></textarea> 
        <?php endif; ?>
    </div>
</div>
<h4>Commission Details</h4>
<h6>Commission 1</h6>
<hr/>
<div class="row">
    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Name</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_name" name="commission_1_name" placeholder="Enter Name"
            value="<?php echo e($invoice->commission_1_name); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_name" name="commission_1_name" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_name); ?><?php else: ?><?php echo e(old('commission_1_name')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_amount" name="commission_1_amount" placeholder="Enter Amount"
            value="<?php echo e($invoice->commission_1_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_amount" name="commission_1_amount" placeholder="Enter Amount"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_amount); ?><?php else: ?><?php echo e(old('commission_1_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>

	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">TDS Deducted by Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_tds" name="commission_1_tds" placeholder="Enter TDS Deducted by company"
            value="<?php echo e($invoice->commission_1_tds); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_tds" name="commission_1_tds" placeholder="Enter TDS Deducted by company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_tds); ?><?php else: ?><?php echo e(old('commission_1_tds')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount Paid Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_company_amount" name="commission_1_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php echo e($invoice->commission_1_company_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_company_amount" name="commission_1_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_company_amount); ?><?php else: ?><?php echo e(old('commission_1_company_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Cheque no</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_cheque_no" name="commission_1_cheque_no" placeholder="Enter Cheque No"
            value="<?php echo e($invoice->commission_1_cheque_no); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_cheque_no" name="commission_1_cheque_no" placeholder="Enter Cheque No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_cheque_no); ?><?php else: ?><?php echo e(old('commission_1_cheque_no')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Date</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_1_date" name="commission_1_date" placeholder="Enter Date"
            value="<?php echo e($invoice->commission_1_date); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_1_date" name="commission_1_date" placeholder="Enter Date"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_1_date); ?><?php else: ?><?php echo e(date('d/M/Y')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>  
</div>
<h6>Commission 2</h6>
<hr/>
<div class="row">

    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Name</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_name" name="commission_2_name" placeholder="Enter Name"
            value="<?php echo e($invoice->commission_2_name); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_name" name="commission_2_name" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_name); ?><?php else: ?><?php echo e(old('commission_2_name')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_amount" name="commission_2_amount" placeholder="Enter Amount"
            value="<?php echo e($invoice->commission_2_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_amount" name="commission_2_amount" placeholder="Enter Amount"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_amount); ?><?php else: ?><?php echo e(old('commission_2_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>

	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">TDS Deducted by Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_tds" name="commission_2_tds" placeholder="Enter TDS Deducted by company"
            value="<?php echo e($invoice->commission_2_tds); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_tds" name="commission_2_tds" placeholder="Enter TDS Deducted by company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_tds); ?><?php else: ?><?php echo e(old('commission_2_tds')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount Paid Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_company_amount" name="commission_2_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php echo e($invoice->commission_2_company_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_company_amount" name="commission_2_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_company_amount); ?><?php else: ?><?php echo e(old('commission_2_company_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Cheque no</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_cheque_no" name="commission_2_cheque_no" placeholder="Enter Cheque No"
            value="<?php echo e($invoice->commission_2_cheque_no); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_cheque_no" name="commission_2_cheque_no" placeholder="Enter Cheque No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_cheque_no); ?><?php else: ?><?php echo e(old('commission_2_cheque_no')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Date</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_2_date" name="commission_2_date" placeholder="Enter Date"
            value="<?php echo e($invoice->commission_2_date); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_2_date" name="commission_2_date" placeholder="Enter Date"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_2_date); ?><?php else: ?><?php echo e(date('d/M/Y')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>  
</div>
<h6>Commission 3</h6>
<hr/>
<div class="row">



    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Name</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_name" name="commission_3_name" placeholder="Enter Name"
            value="<?php echo e($invoice->commission_3_name); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_name" name="commission_3_name" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_name); ?><?php else: ?><?php echo e(old('commission_3_name')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_amount" name="commission_3_amount" placeholder="Enter Amount"
            value="<?php echo e($invoice->commission_3_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_amount" name="commission_3_amount" placeholder="Enter Amount"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_amount); ?><?php else: ?><?php echo e(old('commission_3_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>

	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">TDS Deducted by Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_tds" name="commission_3_tds" placeholder="Enter TDS Deducted by company"
            value="<?php echo e($invoice->commission_3_tds); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_tds" name="commission_3_tds" placeholder="Enter TDS Deducted by company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_tds); ?><?php else: ?><?php echo e(old('commission_3_tds')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount Paid Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_company_amount" name="commission_3_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php echo e($invoice->commission_3_company_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_company_amount" name="commission_3_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_company_amount); ?><?php else: ?><?php echo e(old('commission_3_company_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Cheque no</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_cheque_no" name="commission_3_cheque_no" placeholder="Enter Cheque No"
            value="<?php echo e($invoice->commission_3_cheque_no); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_cheque_no" name="commission_3_cheque_no" placeholder="Enter Cheque No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_cheque_no); ?><?php else: ?><?php echo e(old('commission_3_cheque_no')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Date</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_3_date" name="commission_3_date" placeholder="Enter Date"
            value="<?php echo e($invoice->commission_3_date); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_3_date" name="commission_3_date" placeholder="Enter Date"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_3_date); ?><?php else: ?><?php echo e(date('d/M/Y')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>  
</div>
<h6>Commission 4</h6>
<hr/>
<div class="row">
    <div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Name</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_name" name="commission_4_name" placeholder="Enter Name"
            value="<?php echo e($invoice->commission_4_name); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_name" name="commission_4_name" placeholder="Enter Bill No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_name); ?><?php else: ?><?php echo e(old('commission_4_name')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_amount" name="commission_4_amount" placeholder="Enter Amount"
            value="<?php echo e($invoice->commission_4_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_amount" name="commission_4_amount" placeholder="Enter Amount"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_amount); ?><?php else: ?><?php echo e(old('commission_4_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>

	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">TDS Deducted by Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_tds" name="commission_4_tds" placeholder="Enter TDS Deducted by company"
            value="<?php echo e($invoice->commission_4_tds); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_tds" name="commission_4_tds" placeholder="Enter TDS Deducted by company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_tds); ?><?php else: ?><?php echo e(old('commission_4_tds')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="name">Amount Paid Company</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_company_amount" name="commission_4_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php echo e($invoice->commission_4_company_amount); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_company_amount" name="commission_4_company_amount" placeholder="Enter Amount Paid to company"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_company_amount); ?><?php else: ?><?php echo e(old('commission_4_company_amount')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Cheque no</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_cheque_no" name="commission_4_cheque_no" placeholder="Enter Cheque No"
            value="<?php echo e($invoice->commission_4_cheque_no); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_cheque_no" name="commission_4_cheque_no" placeholder="Enter Cheque No"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_cheque_no); ?><?php else: ?><?php echo e(old('commission_4_cheque_no')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>
	<div class="form-group col-sm-4">
        <label class="text-capitalize" for="subject">Date</label>
        <?php if(isset($invoice)): ?>
            <input type="text" class="form-control text-capitalize" id="commission_4_date" name="commission_4_date" placeholder="Enter Date"
            value="<?php echo e($invoice->commission_4_date); ?>" >
        <?php else: ?>
            <input type="text" class="form-control text-capitalize"  id="commission_4_date" name="commission_4_date" placeholder="Enter Date"
            value="<?php if(isset($invoice)): ?><?php echo e($invoice->commission_4_date); ?><?php else: ?><?php echo e(date('d/M/Y')); ?><?php endif; ?>" >
        <?php endif; ?>
    </div>  
</div>
<div class="form-group">
    <button type="submit" class="btn btn-success">
        <?php if(isset($invoice)): ?>
            Save
        <?php else: ?>
            <?php if(isset($client)): ?>
                Update
            <?php else: ?>
                Create
            <?php endif; ?>
        <?php endif; ?>
    </button>
    <a class="btn btn-danger ml-3" href="<?php echo e(route('clients.index')); ?>">Cancel</a>
</div>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="<?php echo e(url('/').'/js/jquery.replicate.js'); ?>"></script>

<script>
		
		jQuery(function(){
  jQuery("input[name='contact_no']").on('input', function (e) {
    jQuery(this).val($(this).val().replace(/[^0-9]/g, ''));
  });
});
function otherSelect(event) {
	
 var other = document.getElementById("otherBox");
 if ($( "#payment_mode  option:selected" ).text() == "Cheque") {
 other.style.visibility = "visible";
 }
 else {
 other.style.visibility = "hidden";
 }
 }

 
 const selector = '[data-x-wrapper]';
        let options = {
            disableNaming: '[data-disable-naming]',
            wrapper: selector,
            group: '[data-x-group]',
            addBtn: '[data-add-btn]',
            removeBtn: '[data-remove-btn]'
        };
 
        $(selector).replicate(options);
$(document).ready(function(){
  $("#property_amount").keyup(function(){
    var gst = $(this).val() * 0.18;
    var tds = $(this).val() * 0.05;
	var amount_for_developer = parseFloat($(this).val()) + parseFloat(gst) ;
	var amount_after_tds = parseFloat($(this).val()) - parseFloat(tds) ;
	$('#gst').val(gst);
	$('#amount_for_developer').val(amount_for_developer);
	$('#tds').val(tds);
	$('#amount_after_tds').val(amount_after_tds);
	$('#after_customer_passon').val(amount_after_tds);
  });
});
</script><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/invoices/form.blade.php ENDPATH**/ ?>