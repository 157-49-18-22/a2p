<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/vendor/adminlte/partials/navbar/menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>