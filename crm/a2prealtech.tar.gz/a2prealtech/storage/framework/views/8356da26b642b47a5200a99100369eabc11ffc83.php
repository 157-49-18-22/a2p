<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payer">User</label>
       <select class="form-control js-example-basic-single" id="user_id" name="user_id" required>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" >
                    <?php echo e($user->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="amount">Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control text-capitalize" id="amount" name="amount"
        value="" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" name="payment_mode" required>
            <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($payment_mode->id); ?>">
                    <?php echo e($payment_mode->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>



<div class="form-group">
    <input type="submit" class="btn btn-success" value="Add">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('wallet.index')); ?>">Cancel</a>
</div>
<?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/wallet/form.blade.php ENDPATH**/ ?>