<?php $__env->startSection('title', 'Wallet'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Wallet</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('wallet.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add Money</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">User</th>
                        <th class="text-uppercase" scope="col">Amount</th>
                        <th class="text-uppercase" scope="col">Added on </th>
                        <th class="text-uppercase" scope="col">Balance</th>
                        <!--th class="text-uppercase" scope="col">Action</th-->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($due['id']); ?></td>
                        <td><?php echo e($due['name']); ?></td>
                        <td><?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($due['amount']); ?></td>
                        <td><?php echo e($due['created_at']); ?></td>
                        <td><?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($due['balance']); ?></td>
                        <!--td>
                            
                        </td-->
                    </tr>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   

                </tbody>
            </table>
            <?php if(count($wallet) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">

        </div>

        <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('wallet.index')); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/due_payment.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/wallet/index.blade.php ENDPATH**/ ?>