<?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php echo csrf_field(); ?>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payer">Payer</label>
        <input type="text" class="form-control text-capitalize" id="payer" name="payer" placeholder="Payer name"
        value="<?php if(isset($payment)): ?><?php echo e($payment->payer); ?><?php else: ?><?php echo e(old('payer')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="amount">Amount (<?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?>)</label>
        <input type="number" step="0.01" class="form-control text-capitalize" id="amount" name="amount"
        value="<?php if(isset($payment)): ?><?php echo e($payment->amount); ?><?php else: ?><?php echo e(old('amount')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="date_of_payment">Date Of Payment</label>
        <input type="date" class="form-control" id="date_of_payment" name="date_of_payment"
        value="<?php if(isset($payment)): ?><?php echo e($payment->date_of_payment->format('Y-m-d')); ?><?php else: ?><?php echo e(old('date_of_payment')); ?><?php endif; ?>" required>
    </div>
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="payment_mode">Payment Mode</label>
        <select class="form-control js-example-basic-single" id="payment_mode" name="payment_mode" required>
            <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($payment_mode->id); ?>" <?php if(isset($payment)): ?> <?php if($payment_mode->id == $payment->payment_mode->id): ?> selected <?php endif; ?> <?php endif; ?>>
                    <?php echo e($payment_mode->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="row">
    <div class="form-group col-sm-3">
        <label class="text-capitalize" for="remark">Remark</label>
        <input type="text" class="form-control" id="remark" name="remark" placeholder="Remark"
        value="<?php if(isset($payment)): ?><?php echo e($payment->remark); ?><?php else: ?><?php echo e(old('remark')); ?><?php endif; ?>">
    </div>
</div>

<div class="form-group">
    <input type="submit" class="btn btn-success" value="<?php if(isset($payment)): ?> Update <?php else: ?> Create <?php endif; ?>">
    <a class="btn btn-danger ml-3" href="<?php echo e(route('payments.index')); ?>">Cancel</a>
</div>
<?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/payments/form.blade.php ENDPATH**/ ?>