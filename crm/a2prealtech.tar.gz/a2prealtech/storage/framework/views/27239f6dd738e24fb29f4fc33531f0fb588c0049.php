<?php $__env->startSection('title', 'Edit Roles'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Roles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
        <?php if($errors->any()): ?>
    <div class="border border-danger text-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    <form method="post" action="<?php echo e(route('roles.edit', ['id' => $roles->id])); ?>">  
<?php echo csrf_field(); ?>

			<div class="row">
				<div class="form-group col-sm-8">
					<label class="text-capitalize" for="name">Name</label>
					<input type="text" class="form-control text-capitalize" id="name" name="name" placeholder="Role Name"
					value="<?php echo e($roles->name); ?>" required>
				</div>
				<div class="form-group col-sm-12">
					<label class="text-capitalize" for="details">Permissions</label>
					<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
							<div class="form-check" >
							  <input class="form-check-input" type="checkbox" name='permissions[]' value="<?php echo e($p->id); ?>" id="flexCheckDefault"  <?php if($p->id == $p->permission_id ): ?> <?php echo e('checked'); ?> <?php endif; ?>
							 >
							  <label class="form-check-label" for="flexCheckDefault">
							 <?php echo e($p->name); ?>

							  </label>
							</div>
							
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
			</div>

			<div class="form-group">
				<input type="submit" class="btn btn-success" value="Update">
				<a class="btn btn-danger ml-3" href="<?php echo e(route('roles.index')); ?>">Cancel</a>
			</div>
          
        </div>
</form>
        
       

    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/user_lost.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/roles/edit.blade.php ENDPATH**/ ?>