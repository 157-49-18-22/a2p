<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>User Details</h1>
    <div id="<?php echo e($user->id); ?>" class="my-3">
        <?php if($user->id !== auth()->user()->id): ?>
        <button class="entry-delete-btn btn btn-danger text-uppercase float-right ml-2">
            <i class="fas fa-trash-alt fa-fw"></i>
            <span class="big-btn-text">Delete This User</span>
        </button>
        <a class="btn btn-primary text-uppercase float-right ml-2" href="<?php echo e(route('useraccounts.edit', ['id' => $user->id])); ?>">
            <i class="fas fa-edit fa-fw"></i>
            <span class="big-btn-text">Edit This user</span>
        </a>
        <?php endif; ?>
        <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('useraccounts.create')); ?>">
            <i class="fas fa-plus fa-fw"></i>
            <span class="big-btn-text">Add New user</span>
        </a>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card px-3 py-2">
        <div class="row">
            <div class="col-6">
                <ul class="list-group">
                    <li class="list-group-item">
                        <span>#</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($user->id); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Name</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($user->name); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Email</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($user->email); ?></span>
                    </li>
					<li class="list-group-item">
                        <span>Phone</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($user->phone); ?></span>
                    </li>
					<li class="list-group-item">
                        <span>Address</span>:
                        <span class="pl-1 font-weight-bolder"><?php echo e($user->address); ?></span>
                    </li>
                    <li class="list-group-item">
                        <span>Photo</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($user->photo_url)): ?>
                            <a href="<?php echo e(url('/storage/galeryImages').'/'. $user->photo_url); ?>" target="_blank" rel="noopener noreferrer">
                                <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'.$user->photo_url); ?>" alt='profile photo'
                                class="img-thumbnail" />
                            </a>
                            <?php else: ?>
                            <span class="text-secondary">
                                <i class="fas fa-user-circle fa-lg"></i>
                            </span>
                            <?php endif; ?>
                        </span>
                    </li>
					  <li class="list-group-item">
                        <span>Aadhar</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($user->aadhar)): ?>
                            <a href="<?php echo e(url('/storage/galeryImages').'/'. $user->aadhar); ?>" target="_blank" rel="noopener noreferrer">
                                <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'.$user->aadhar); ?>" alt='profile photo'
                                class="img-thumbnail" />
                            </a>
                            <?php else: ?>
                            <span class="text-secondary">
                                <i class="fas fa-user-circle fa-lg"></i>
                            </span>
                            <?php endif; ?>
                        </span>
                    </li>
					 <li class="list-group-item">
                        <span>Pan Card</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php if(isset($user->pancard)): ?>
                            <a href="<?php echo e(url('/storage/galeryImages').'/'. $user->pancard); ?>" target="_blank" rel="noopener noreferrer">
                                <img height="42" width="42" src="<?php echo e(url('/storage/galeryImages').'/'.$user->pancard); ?>" alt='profile photo'
                                class="img-thumbnail" />
                            </a>
                            <?php else: ?>
                            <span class="text-secondary">
                                <i class="fas fa-user-circle fa-lg"></i>
                            </span>
                            <?php endif; ?>
                        </span>
                    </li>
                    <li class="list-group-item">
                        <span>Role</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e(implode(', ', $user->roles->pluck('name')->toArray())); ?>

                        </span>
                    </li>
					 <li class="list-group-item">
                        <span>Location</span>:
                        <span class="pl-1 font-weight-bolder">
                            <?php echo e($user->location); ?>

                        </span>
                    </li>
                </ul>

            </div>
        </div>
    </div>

    
    <input type="hidden" id="deleteUrl<?php echo e($user->id); ?>" value="<?php echo e(route('useraccounts.destroy', ['id' => $user->id])); ?>">
    <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('useraccounts.index')); ?>">
    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
    <input type="hidden" id="deletedTitle" value="Deleted!">
    <input type="hidden" id="deletedMsg" value="The selected project was successfully deleted.">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/useraccounts/show.blade.php ENDPATH**/ ?>