<?php $__env->startSection('title', 'All Users'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>All Roles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('roles.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add New Role</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Name</th>
                     
                        <th class="text-uppercase" scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->id); ?></td>
                        <td><?php echo e($role->name); ?></td>
                       
                        <td>
                            <div class="dropdown">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-boundary="viewport">
                                    ACTIONS
                                </a>
                                <div id="" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item text-primary"
                                        href="">View</a>
                                   
                                    <a class="dropdown-item text-primary"
                                        href="<?php echo e(route('roles.edit', ['id' => $role->id])); ?>">Edit</a>
                                    <div class="dropdown-divider"></div>
                                   
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  
                </tbody>
            </table>
            <?php if(count($roles) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
       

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/user_lost.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/roles/index.blade.php ENDPATH**/ ?>