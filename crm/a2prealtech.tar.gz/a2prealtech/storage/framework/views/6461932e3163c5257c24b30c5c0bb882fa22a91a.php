<?php $__env->startSection('title', 'Add New Expense'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add New Expense</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('expenses.store')); ?>" enctype="multipart/form-data">
        <?php echo $__env->make('expenses.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/s2.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/expenses/create.blade.php ENDPATH**/ ?>