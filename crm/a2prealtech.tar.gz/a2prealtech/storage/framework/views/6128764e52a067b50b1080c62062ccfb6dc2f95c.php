<?php $__env->startSection('title', 'All Expenses'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row">
    <div class="col-md-9"><h1>All Expenses</h1></div>
    <div class="col-md-3">    
		<?php if(!empty($wallet)): ?>
		<div class="btn wallet-balance text-uppercase float-right" >
                <span class="big-btn-text">Wallet Balance : <?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php if($wallet->balance): ?> <?php echo e($wallet->balance); ?> <?php else: ?> <?php echo e('0'); ?> <?php endif; ?></span>
		</div>
		<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_create')): ?>
        <div class="my-3">
            <a class="btn btn-success text-uppercase float-right" href="<?php echo e(route('expenses.create')); ?>">
                <i class="fas fa-plus fa-fw"></i>
                <span class="big-btn-text">Add New Expense</span>
            </a>
        </div>
        <?php endif; ?>
        <input type="text" id="searchBox" placeholder="🔍 Search the table below">
        <br>

        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th class="text-uppercase" scope="col">#</th>
                        <th class="text-uppercase" scope="col">Payee</th>
                        <th class="text-uppercase" scope="col">Amount Paid</th>
                        <th class="text-uppercase" scope="col">Date Of Payment</th>
                        <th class="text-uppercase" scope="col">Status</th>
                        <th class="text-uppercase" scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($expense->id); ?></td>
                        <td><?php echo e($expense->payee); ?></td>
                        <td><?php echo e(App\Lancer\Utilities::CURRENCY_SYMBOL); ?> <?php echo e($expense->amount_paid); ?></td>
                        <td><?php echo e($expense->date_of_payment->format('d-M-Y')); ?></td>
                        <td><?php echo e($expense->status); ?></td>
                        <td>
                            <div class="dropdown">
                                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-boundary="viewport">
                                    ACTIONS
                                </a>
								<?php if($expense->status != 'Paid'){?>
                                <div id="<?php echo e($expense->id); ?>" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_edit')): ?>
                                        <a class="dropdown-item text-primary"
                                            href="<?php echo e(route('expenses.edit', ['id' => $expense->id])); ?>">Edit</a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_delete')): ?>
                                    <div class="dropdown-divider"></div>
                                    <?php if(!$expense->is_active): ?>
                                        <a role="button" class="entry-delete-btn dropdown-item text-danger" style="">
                                            Delete This Expense
                                        </a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
								<?php }?>
                            </div>
                        </td>
                    </tr>
                    <input type="hidden" id="deleteUrl<?php echo e($expense->id); ?>" value="<?php echo e(route('expenses.destroy', ['id' => $expense->id])); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <input type="hidden" id="deletedBtnText" value="Yes, delete it!">
                    <input type="hidden" id="deletedTitle" value="Deleted!">
                    <input type="hidden" id="deletedMsg" value="The selected expense was successfully deleted.">

                </tbody>
            </table>
            <?php if(count($expenses) < 1): ?>
                <div class="px-4 py-5 mx-auto text-secondary">
                    No results found!
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4">
            <?php echo e($expenses->links()); ?>

        </div>

        <input type="hidden" id="closedRedirectUrl" value="<?php echo e(route('expenses.index')); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<style>
.wallet-balance {
    background-color: #ff0000 !important;
    color: #fff !important;
    font-weight: 600 !important;
}
</style>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/table_utils.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/delete_entry.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u217993607/domains/famepixel.com/public_html/projects/a2prealtech/resources/views/expenses/index.blade.php ENDPATH**/ ?>